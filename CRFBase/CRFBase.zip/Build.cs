﻿using CRFBase.GibbsSampling;
using General.BasicObject;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CRFBase
{
    public static class Build
    {
        public static void Do(IContext context = null)
        {
            new ComputeOrderManager(context);
            new InferenceManager(context);
            new GibbsSamplingManager(context);
        }
    }
}
