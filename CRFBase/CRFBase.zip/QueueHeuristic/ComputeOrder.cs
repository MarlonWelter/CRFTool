﻿using General.BasicObject;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CRFBase
{
    /**
     * Nodes: The nodes, that needs to be brought to order
     * 
     * StartPatch: The nodes that are allready selected
     * 
     * 
     * */
    public class ComputeOrder : IHas<IRequestLogic<ComputeOrder>>
    {
        public ComputeOrder(IEnumerable<CRFNode> nodes, IEnumerable<CRFNode> startPatch)
        {
            StartPatch = startPatch;
            Nodes = nodes;
        }

        private LinkedList<CRFNode> orderedNodes = new LinkedList<CRFNode>();
        public LinkedList<CRFNode> OrderedNodes
        {
            get { return orderedNodes; }
            set { orderedNodes = value; }
        }

        public IEnumerable<CRFNode> StartPatch { get; set; }
        public IEnumerable<CRFNode> Nodes { get; set; }


        private RequestLogic<ComputeOrder> logic = new RequestLogic<ComputeOrder>();
        public IRequestLogic<ComputeOrder> Logic { get { return logic; } }
    }

    class ComputeOrderManager : IRequestListener
    {
        public ComputeOrderManager(IContext context = null)
        {
            Context = context;
            Register();
        }
        public IContext Context { get; set; }
        public void Register()
        {
            this.DoRegister<ComputeOrder>(OnComputeOrder);
        }

        private void OnComputeOrder(ComputeOrder obj)
        {
            var resultingOrder = GreedyMinBorderQueueComputing.ComputeQueue(obj.Nodes.ToList(), obj.StartPatch);
            obj.OrderedNodes = resultingOrder;
        }

        public void Unregister()
        {
            this.DoUnregister<ComputeOrder>(OnComputeOrder);
        }
    }
}
