﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using General.BasicObject;
using General.BasicOperation;
using General.General;
using System.IO;

namespace CRFBase
{
    class GreedyMinBorderQueueComputing
    {
        public static string MaxQueueFile = "";
        public static int maximumBorder;
        public static int workingMSA = 0;
        public static int problemMSA = 0;
        private static Dictionary<CRFNode, ICollection<CRFEdge>> OutsideEdges = new Dictionary<CRFNode, ICollection<CRFEdge>>();

        public static LinkedList<CRFNode> ComputeQueue(IList<CRFNode> vertices, IEnumerable<CRFNode> startPatch)
        {
            var startTime = DateTime.Now;

            if (startPatch == null)
                startPatch = new LinkedList<CRFNode>();

            startPatch.Each(n => n.IsChosen = true);
            OutsideEdges.Clear();

            foreach (var item in vertices)
            {
                OutsideEdges.Add(item, item.Edges().Where<CRFEdge>(e => !item.Neighbour(e).IsChosen).ToList());
                item.IsInQueue = false;
                
            }

            LinkedList<CRFNode> queue = new LinkedList<CRFNode>();
            maximumBorder = 0;


            while (queue.Count < vertices.Count() - startPatch.Count())
            {

                int minimumOutsideEdges = vertices.Count();
                int minimumIndex = -1;
                //int bordercount = 0;

                for (int counter = 0; counter < vertices.Count(); counter++)
                {

                    var vertexInFocus = vertices[counter];
                    if (vertexInFocus.IsChosen)
                        continue;
                    if (OutsideEdges[vertexInFocus].Count > 0 || (!vertexInFocus.IsInQueue))
                    {
                        if (OutsideEdges[vertexInFocus].Count < minimumOutsideEdges)
                        {
                            minimumIndex = counter;
                            minimumOutsideEdges = OutsideEdges[vertexInFocus].Count;
                        }
                    }
                }

                var minimumOutsideEdgesVertex = vertices[minimumIndex];


                if (!queue.Contains(minimumOutsideEdgesVertex))
                {
                    queue.AddLast(minimumOutsideEdgesVertex);
                    minimumOutsideEdgesVertex.IsInQueue = true;
                    RemoveInnerEdges(queue);
                    countBorder(queue);
                }

                //Make the list of the vertices you want to add
                LinkedList<CRFNode> verticesToAdd = new LinkedList<CRFNode>();
                foreach (CRFEdge edge in OutsideEdges[minimumOutsideEdgesVertex])
                {
                    verticesToAdd.AddLast(minimumOutsideEdgesVertex.Neighbour(edge));
                }

                foreach (CRFNode vertexToAdd in verticesToAdd)
                {

                    if (!queue.Contains(vertexToAdd))
                    {

                        queue.AddLast(vertexToAdd);
                        vertexToAdd.IsInQueue = true;

                        //remove edges that are now inside
                        RemoveInnerEdges(queue);

                        countBorder(queue);
                    }
                    else
                    {
                        Console.WriteLine("Inkonsistenz in Queue-Berechnung!");
                    }
                }


            }
            if (maximumBorder < 22)
            {
                //Console.WriteLine("biggest historyset-boundary: " + maximumBorder);
                if (MaxQueueFile != string.Empty)
                {
                    using (var writer = File.AppendText(MaxQueueFile))
                    {
                        writer.WriteLine(maximumBorder);
                    }
                }
                workingMSA++;
            }
            else
            {
                Console.WriteLine("biggest historyset-boundary: " + maximumBorder);
                if (MaxQueueFile != string.Empty)
                {
                    using (var writer = File.AppendText(MaxQueueFile))
                    {
                        writer.WriteLine(maximumBorder);
                    }
                }
                problemMSA++;
            }

            Console.WriteLine("Computed Queue in " + (DateTime.Now - startTime));

            int ctr = 0;
            foreach (var item in queue)
            {
                item.Ordinate = ctr;
                ctr++;
            }

            return queue;
        }

        public static LinkedList<CRFNode> QueueComputeMethod2(CRFNode[] vertices)
        {
            LinkedList<CRFNode> queue = new LinkedList<CRFNode>();
            maximumBorder = 0;

            while (queue.Count < vertices.Count())
            {

                int optimumIndex = -1;
                int optimumScore = -vertices.Count();
                int goodEdges = 0;
                int BadEdges = 0;
                int score = 0;

                for (int counter = 0; counter < vertices.Count(); counter++)
                {
                    score = 0;
                    goodEdges = 0;
                    BadEdges = 0;

                    var vertexInFocus = vertices[counter];

                    if (!queue.Contains(vertexInFocus))
                    {

                        if (OutsideEdges[vertexInFocus].Count <= 0)
                        {
                            optimumIndex = counter;
                            break;
                        }
                        else
                        {
                            foreach (var edge in vertexInFocus.Edges())
                            {
                                if (queue.Contains(vertexInFocus.Neighbour(edge)))
                                    goodEdges++;
                                BadEdges++;
                            }
                            score = goodEdges - BadEdges;

                            if (score > optimumScore)
                            {
                                optimumScore = score;
                                optimumIndex = counter;
                            }
                        }
                    }

                }

                var bestScoreVertex = vertices[optimumIndex];


                if (!queue.Contains(bestScoreVertex))
                {
                    queue.AddLast(bestScoreVertex);
                    RemoveInnerEdges(queue);
                    countBorder(queue);
                }

                RemoveInnerEdges(queue);
                countBorder(queue);


            }

            if (maximumBorder < 22)
            {
                //Console.WriteLine("biggest historyset-boundary: " + maximumBorder);
                workingMSA++;
            }
            else
            {
                //Console.WriteLine("biggest historyset-boundary: " + maximumBorder);
                problemMSA++;
            }

            return queue;
        }


        private static void countBorder(LinkedList<CRFNode> queue)
        {

            int bordercount = 0;
            int checksum = 0;

            foreach (CRFNode vertex in queue)
            {
                if (OutsideEdges[vertex].Count > 0)
                    bordercount++;
                if (OutsideEdges[vertex].Count == 0)
                    checksum++;
            }
            if (bordercount + checksum != queue.Count)
                Console.WriteLine("Inkonsistenz in Queue-Berechnung!");

            if (bordercount > maximumBorder)
                maximumBorder = bordercount;

            //Console.WriteLine("Iteration: "+ queue.Count() + " - bordercount: " + bordercount);

        }

        private static void RemoveInnerEdges(LinkedList<CRFNode> queue)
        {
            LinkedList<CRFEdge> rememberToRemove = new LinkedList<CRFEdge>();
            foreach (var item in queue)
            {
                foreach (CRFEdge edge in OutsideEdges[item])
                {
                    if (item.Neighbour(edge).IsInQueue)
                    {
                        if (!rememberToRemove.Contains(edge))
                            rememberToRemove.AddLast(edge);
                    }
                }
            }

            foreach (CRFEdge edge in rememberToRemove)
            {
                OutsideEdges[edge.Head()].Remove(edge);
                OutsideEdges[edge.Foot()].Remove(edge);
            }
        }

    }
}