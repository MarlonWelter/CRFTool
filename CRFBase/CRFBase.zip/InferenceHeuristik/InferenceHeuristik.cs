﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;
using General.BasicOperation;
using General.General;
using General.Algorithms;
using General.Logging;
using System.Diagnostics;
using General.Events;
using General.MathCompartement;

namespace CRFBase
{
    class inferenceHeuristik
    {
        public readonly int MaximalCombinationsUnderConsideration;
        public const int PossibleStatesForVertices = 2;
        readonly List<CRFNode> ChosenVertices = new List<CRFNode>();
        internal List<CRFNode> BoundaryVertices = new List<CRFNode>();
        public List<Combination> Combinations = new List<Combination>();
        LinkedList<Combination> NextGeneration = new LinkedList<Combination>();
        readonly Dictionary<string, Combination> BorderCombinations = new Dictionary<string, Combination>();
        public double Barrier { get; set; }
        private const int RunsToDetermineBarrier = 100;
        private Random Random = new Random();
        public CRFGraph Graph { get; set; }

        ////if this field is true, then after one run of the algorithm - the interface assignments will be reprocessed to a weighted voting by the top results
        //public const bool ReprocessTopResults = true;
        public const bool KeepOnlyTopResult = true;
        //private ComputeNewCombinations ComputeNewCombination = new ComputeNewCombinations(PossibleStatesForVertices);
        private Func<IList<CRFNode>, IEnumerable<CRFNode>, LinkedList<CRFNode>> computeQueue = GreedyMinBorderQueueComputing.ComputeQueue;
        public Func<IList<CRFNode>, IEnumerable<CRFNode>, LinkedList<CRFNode>> ComputeQueue
        {
            get { return computeQueue; }
            set { computeQueue = value; }
        }


        public inferenceHeuristik(int maxCombinationsUnderConsideration)
        {
            MaximalCombinationsUnderConsideration = maxCombinationsUnderConsideration;

            AnnounceNewCombination.AddPath(newCombination => NextGeneration.AddLast(newCombination));
        }

        public CRFResult Run(CRFGraph graph, IDictionary<CRFNode, int> startLabeling)
        {
            Graph = graph;
            graph.Nodes.Each(n => n.IsChosen = false);
            var startPatch = (startLabeling != null) ? startLabeling.Keys : new List<CRFNode>();
            LinkedList<CRFNode> vertexQueue = computeQueue(graph.Nodes, startPatch);

            //preparation
            int counter = 0;
            foreach (var item in startPatch)
            {
                item.IsChosen = true;
            }
            foreach (var item in vertexQueue)
            {
                item.Ordinate = counter;
                counter++;
                item.UnchosenNeighboursTemp = item.Edges().Where(e => !item.Neighbour(e).IsChosen).Count();
            }

            //Create starting Combination
            {
                Combination newCombination = new Combination();
                newCombination.Assignment = new int[Graph.Nodes.Count - startPatch.Count];

                var score = 0.0;
                if (startLabeling != null)
                {
                    foreach (var item in startLabeling)
                    {
                        score += item.Key.Score(item.Value);
                    }

                    foreach (var edge in graph.Edges)
                    {
                        if (edge.Head().IsChosen && edge.Foot().IsChosen)
                        {
                            score += edge.Score(startLabeling[edge.Head()], startLabeling[edge.Foot()]);
                        }
                    }
                }
                newCombination.BorderFingerPrint = "";
                Combinations.Add(newCombination);
            }

            Stopwatch watch = new Stopwatch();
            watch.Start();

            foreach (var vertex in vertexQueue)
            {
                vertex.IsChosen = true;
                LinkedList<CRFNode> NewInnerVertices = ComputeNewBoundaryVertices(vertex);

                Barrier = DetermineBarrier(Combinations, vertex, NewInnerVertices.Count == 0, MaximalCombinationsUnderConsideration, RunsToDetermineBarrier);

                Do(Combinations, vertex, NewInnerVertices, comb => comb.Score >= Barrier, BoundaryVertices);

                //filter step two
                if (NextGeneration.Count > MaximalCombinationsUnderConsideration)
                {
                    var ng = NextGeneration.ToList();
                    var barrier2 = DetermineBarrierStep2(ng, MaximalCombinationsUnderConsideration, RunsToDetermineBarrier);
                    NextGeneration = new LinkedList<Combination>(ng.Where(item => item.Score >= barrier2));
                }

                Combinations = NextGeneration.ToList();
                NextGeneration.Clear();

                //Log.Post("Vertex: " + vertex.Id + " " + vertex.Ordinate + @"/" + vertexQueue.Count);
                //Log.Post("Barrier: " + Barrier + "   Combinations: " + Combinations.Count);
            }
            watch.Stop();
            //Log.Post("Time Used: " + watch.ElapsedMilliseconds);

            //return result
            var result = new CRFResult();
            if (startLabeling != null)
                result.Labeling.AddRange(startLabeling);
            var winner = Combinations[0];
            foreach (var node in vertexQueue)
            {
                result.Labeling.Add(node, winner.Assignment[node.Ordinate]);
            }
            result.RunTime = watch.Elapsed;
            result.Score = winner.Score;

            return result;
        }

        private double DetermineBarrierStep2(List<Combination> Combinations, int MaximalCombinationsUnderConsideration, int RunsToDetermineBarrier)
        {

            var surviveRatio = ((double)MaximalCombinationsUnderConsideration) / (Combinations.Count);

            var sample = Combinations.RandomTake(RunsToDetermineBarrier, Random).ToList();

            double barrier = 0.0;
            int sampleCount = sample.Count;

            int survivors = (int)(surviveRatio * sampleCount) + 1;
            LinkedList<double> Scores = new LinkedList<double>();

            Random rand = new Random();


            foreach (var item in sample)
            {
                LinkedListHandler.SortedInsert(Scores, item.Score, survivors);
            }
            barrier = (Scores.Last.Value + Scores.Last.Previous.Value) / 2.0;

            return barrier;
        }

        private double DetermineBarrier(List<Combination> Combinations, CRFNode vertex, bool needBarrier, int MaximalCombinationsUnderConsideration, int RunsToDetermineBarrier)
        {
            if (!needBarrier)
                return double.MinValue;

            var surviveRatio = ((double)MaximalCombinationsUnderConsideration) / (Combinations.Count * PossibleStatesForVertices);

            if (surviveRatio >= 1.0)
                return double.MinValue;

            var sample = Combinations.RandomTake(RunsToDetermineBarrier, Random).ToList();

            double barrier = 0.0;
            int sampleCount = sample.Count;

            int survivors = (int)(surviveRatio * sampleCount) + 1;
            LinkedList<double> Scores = new LinkedList<double>();

            Random rand = new Random();

            var scoringEdges = vertex.Edges().Where(e => vertex.Neighbour(e).IsChosen).ToList();

            foreach (var item in sample)
            {
                int label = Random.Next(PossibleStatesForVertices);
                var score = item.Score + vertex.Score(label);
                foreach (var edge in scoringEdges)
                {
                    if (edge.Foot().Equals(vertex))
                        score += edge.Score(item.Assignment[edge.Head().Ordinate], label);
                    else
                        score += edge.Score(label, item.Assignment[edge.Foot().Ordinate]);
                }
                LinkedListHandler.SortedInsert(Scores, score, survivors);
            }
            barrier = (Scores.Last.Value + Scores.Last.Previous.Value) / 2.0;

            return barrier;
        }
        public void ClearInput()
        {

            ChosenVertices.Clear();
            BoundaryVertices.Clear();
            Combinations.Clear();

        }

        private LinkedList<CRFNode> ComputeNewBoundaryVertices(CRFNode chosenVertex)
        {
            LinkedList<CRFNode> NewInnerVertices = new LinkedList<CRFNode>();

            foreach (CRFEdge edge in chosenVertex.Edges())
            {
                CRFNode otherVertex = chosenVertex.Neighbour(edge);
                //if (otherVertex.IsChosen)
                //    continue;
                otherVertex.UnchosenNeighboursTemp--;
                if (otherVertex.UnchosenNeighboursTemp == 0)
                {
                    BoundaryVertices.Remove(otherVertex);
                    NewInnerVertices.AddLast(otherVertex);
                }
            }

            if (chosenVertex.UnchosenNeighboursTemp > 0)
                BoundaryVertices.Add(chosenVertex);
            else
                NewInnerVertices.AddLast(chosenVertex);



            return NewInnerVertices;
        }

        public Func<Combination, bool> CombinationFilter { get; set; }
        public readonly MEvent<Combination> AnnounceNewCombination = new MEvent<Combination>();

        public void Do(IList<Combination> Combinations, CRFNode chosenVertex, LinkedList<CRFNode> NewInnerVertices, Func<Combination, bool> combinationFilter, IEnumerable<CRFNode> border)
        {
            CombinationFilter = combinationFilter;
            Do(Combinations, chosenVertex, NewInnerVertices, border);
        }
        public void Do(IList<Combination> Combinations, CRFNode chosenVertex, LinkedList<CRFNode> NewInnerVertices, IEnumerable<CRFNode> border)
        {

            bool hasNewInnerVertices = NewInnerVertices.Count > 0;
            var validNewCombinations = new Dictionary<string, Combination>();

            foreach (Combination combination in Combinations)
            {
                LinkedList<Combination> newCombinations = CreateNextGeneration(chosenVertex, combination);


                foreach (Combination newCombination in newCombinations)
                {
                    if (!CombinationFilter(newCombination))
                        continue;

                    newCombination.BorderFingerPrint = "";
                    int indexer = 0;
                    foreach (var node in border)
                    {
                        if (node.IsChosen && node.UnchosenNeighboursTemp > 0)
                        {
                            newCombination.BorderFingerPrint += newCombination.Assignment[node.Ordinate] > 0 ? "1" : "0";
                            indexer++;
                        }
                    }
                    if (validNewCombinations.ContainsKey(newCombination.BorderFingerPrint))
                    {
                        if (newCombination.Score > validNewCombinations[newCombination.BorderFingerPrint].Score)
                            validNewCombinations[newCombination.BorderFingerPrint] = newCombination;
                    }
                    else
                        validNewCombinations.Add(newCombination.BorderFingerPrint, newCombination);
                }
            }

            foreach (var comb in validNewCombinations.Values)
            {
                AnnounceNewCombination.Enter(comb);
            }
        }
        public LinkedList<Combination> CreateNextGeneration(CRFNode chosenVertex,
               Combination oldCombination)
        {

            LinkedList<Combination> newCombinations = new LinkedList<Combination>();
            for (int counter = 0; counter < PossibleStatesForVertices; counter++)
            {
                Combination newCombination = default(Combination);
                if (counter == PossibleStatesForVertices - 1)
                {
                    newCombination = new Combination();
                    newCombination.Score = oldCombination.Score;
                    newCombination.Assignment = oldCombination.Assignment;
                }
                else
                {
                    newCombination = new Combination(oldCombination);
                    newCombination.Score = oldCombination.Score;
                    Buffer.BlockCopy(oldCombination.Assignment, 0, newCombination.Assignment, 0, oldCombination.Assignment.Length * 4);

                    //newCombination = new Combination();
                    //newCombination.Score = oldCombination.Score;
                    //newCombination.Assignment = oldCombination.Assignment.ToArray();
                }
                newCombination.AddScore(chosenVertex, counter);
                newCombinations.AddLast(newCombination);
            }

            return newCombinations;
        }
    }
}
