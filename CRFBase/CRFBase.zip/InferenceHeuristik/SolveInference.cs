﻿using General.BasicObject;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CRFBase
{
    public class SolveInference : IHas<IRequestLogic<SolveInference>>
    {
        public SolveInference(CRFGraph graph, IDictionary<CRFNode, int> preAssignment, int bufferSize = 0)
        {
            PreAssignment = preAssignment;
            Graph = graph;
            BufferSize = bufferSize;
        }

        public int BufferSize { get; set; }
        public CRFResult Solution { get; set; }
        public IDictionary<CRFNode, int> PreAssignment { get; set; }
        public CRFGraph Graph { get; set; }

        private RequestLogic<SolveInference> logic = new RequestLogic<SolveInference>();
        public IRequestLogic<SolveInference> Logic
        {
            get { return logic; }
        }
    }
}
