﻿using General.BasicObject;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CRFBase
{
    class InferenceManager : IRequestListener
    {
        public const int DefaultBufferSize = 10000;
        public IContext Context { get; set; }

        public InferenceManager(IContext context, int maxCombinationsBuffer = DefaultBufferSize)
        {
            Context = context;
            MaxCombinationsBuffer = maxCombinationsBuffer;
            this.Register();
        }

        public void Register()
        {
            this.DoRegister<SolveInference>(OnSolveInference);
        }
        public void Unregister()
        {
            this.DoUnregister<SolveInference>(OnSolveInference);
        }
        public int MaxCombinationsBuffer { get; set; }

        private void OnSolveInference(SolveInference obj)
        {
            var heuristik = new inferenceHeuristik(obj.BufferSize > 0 ? obj.BufferSize : MaxCombinationsBuffer);
            var result = heuristik.Run(obj.Graph, obj.PreAssignment);
            obj.Solution = result;
        }
    }
}
