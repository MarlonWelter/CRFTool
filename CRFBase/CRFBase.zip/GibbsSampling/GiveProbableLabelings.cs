﻿using General.BasicObject;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CRFBase.GibbsSampling
{
    public class GiveProbableLabelings : IHas<IRequestLogic<GiveProbableLabelings>>
    {
        public GiveProbableLabelings(CRFGraph graph)
        {
            Graph = graph;
        }

        public Dictionary<CRFNode, double> Result { get; set; }
        public CRFGraph Graph { get; set; }

        private RequestLogic<GiveProbableLabelings> logic = new RequestLogic<GiveProbableLabelings>();
        public IRequestLogic<GiveProbableLabelings> Logic
        {
            get { return logic; }
        }
    }
}
