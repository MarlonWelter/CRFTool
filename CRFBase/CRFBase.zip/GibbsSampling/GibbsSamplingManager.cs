﻿using General.BasicObject;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CRFBase.GibbsSampling
{
    class GibbsSamplingManager : IRequestListener
    {
        public const int DefaultStartingPoints = 100;
        public const int DefaultPreRunLength = 1000;
        public const int DefaultRunLength = 99000;
        public IContext Context { get; set; }

        public GibbsSamplingManager(IContext context)
        {
            Context = context;
            this.Register();
        }

        public void Register()
        {
            this.DoRegister<GiveProbableLabelings>(OnGiveProbableLabelings);
        }
        public void Unregister()
        {
            this.DoUnregister<GiveProbableLabelings>(OnGiveProbableLabelings);
        }
        public int MaxCombinationsBuffer { get; set; }

        private void OnGiveProbableLabelings(GiveProbableLabelings obj)
        {
            var watch = new Stopwatch();
            watch.Start();

            var occurences = BasicGibbsSampling.Do(obj.Graph, DefaultStartingPoints, DefaultPreRunLength, DefaultRunLength);

            watch.Stop();

            var result = new Dictionary<CRFNode, double>();

            foreach (var node in occurences.Graph.Nodes)
            {
                result.Add(node, ((double)node.TempCount) / occurences.CountedAssignmentsTotal);
            }

            obj.Result = result;
        }
    }
}
