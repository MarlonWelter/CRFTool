﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using General.General;
using General.BasicOperation;
using General.BasicObject;

namespace CRFBase
{
    public class BasicGibbsSampling
    {
        public const int DefaultBufferFindStartpointViterbi = 25;

        public static void Do(CRFGraph graph, Action<CRFGraph> findStartpoint, Action<CRFGraph, int> changePosition, Action<CRFGraph, int> evaluatePosition, int startpoints, int preRunLength, int runLength)
        {
            graph.Nodes.Each(n => { n.TempCount = 0; });

            for (int startpointcount = 0; startpointcount < startpoints; startpointcount++)
            {
                graph.Nodes.Each(n => { n.LastUpdate = 0; });
                findStartpoint(graph);
                for (int iteration = 1; iteration <= preRunLength; iteration++)
                {
                    changePosition(graph, 0);
                }
                for (int iteration = 1; iteration <= runLength; iteration++)
                {
                    changePosition(graph, iteration);
                }
                evaluatePosition(graph, runLength);
            }
        }

        public static CountOccurences Do(CRFGraph graph, int startpoints, int preRunLength, int runLength)
        {

            var occurences = new CountOccurences(graph);
            Do(graph, FindStartPointNodeProb, ChangePositionDefault, occurences.Count, startpoints, preRunLength, runLength);
            return occurences;
        }

        private static void FindStartPointNodeProb(CRFGraph graph)
        {

            foreach (var item in graph.Nodes)
            {
                item.TempAssign = Math.Log(Random.NextDouble()) < item.Score(0) ? 0 : 1;
            }
        }

        private static void FindStartPointViterbi(CRFGraph graph)
        {
            var request = default(SolveInference);

            (request = new SolveInference(graph, null, DefaultBufferFindStartpointViterbi)).RequestInDefaultContext();

            foreach (var item in request.Solution.Labeling)
            {
                item.Key.TempAssign = item.Value;
            }
        }
        private static Random random;
        public static Random Random
        {
            get { return (random = random ?? new Random()); }
            set { random = value; }
        }

        public static void ChangePositionDefault(CRFGraph graph, int time)
        {
            var node = graph.Nodes.RandomTake(1, Random).First();
            //var score = assignment.TakeScore();

            //compute relative change
            var relChange = 0.0;
            relChange += node.Score((node.TempAssign + 1) % 2) - node.Score(node.TempAssign);

            //old edges Score
            foreach (var edge in node.Logic.Edges)
            {
                relChange -= edge.TempScore();
            }

            //new edges Score
            node.TempAssign = ((node.TempAssign + 1) % 2);
            foreach (var edge in node.Logic.Edges)
            {
                relChange += edge.TempScore();
            }



            if (Random.NextDouble() <= Math.Exp(relChange) / (1.0 + Math.Exp(relChange)))
            {
                //state changed
                node.TempCount += node.TempAssign * (time - node.LastUpdate);
                node.LastUpdate = time;
            }
            else
            {
                //stay in state
                node.TempAssign = ((node.TempAssign + 1) % 2);
            }
        }
    }

    public class CountOccurences
    {
        public CountOccurences(CRFGraph graph)
        {
            Graph = graph;
        }
        public int CountedAssignmentsTotal { get; set; }

        public void Count(CRFNode node, int value)
        {
            node.TempCount += node.TempAssign;
        }

        public CRFGraph Graph { get; set; }

        public void Count(CRFGraph graph, int time)
        {
            foreach (var node in graph.Nodes)
            {
                node.TempCount += node.TempAssign * (time - node.LastUpdate);
            }
            CountedAssignmentsTotal += time;
        }
    }

}
