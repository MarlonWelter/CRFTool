﻿using General.BasicObject;
using General.BasicOperation;
using General.General;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CRFBase
{
    public class CRFGraph
    {
        public CRFGraph()
        {
            Nodes = new List<CRFNode>();
            Edges = new LinkedList<CRFEdge>();
        }
        public List<CRFNode> Nodes { get; set; }
        public LinkedList<CRFEdge> Edges { get; set; }
    }



    public class CRFNode : IHas<INodeLogic<CRFNode, CRFEdge>>
    {
        public CRFNode()
        {

        }
        public CRFNode(string id)
        {
            Id = id;
        }
        public double Score(int state)
        {
            return Scores[state];
        }
        public int UnchosenNeighboursTemp { get; set; }
        public double[] Scores { get; set; }
        public string Id { get; set; }
        public bool IsInQueue { get; set; }
        public bool IsChosen { get; set; }
        public int Ordinate { get; set; }
        public int ReferenceLabel { get; set; }

        public int TempAssign { get; set; }
        public int TempCount { get; set; }
        public int LastUpdate { get; set; }

        private NodeLogic<CRFNode, CRFEdge> logic = new NodeLogic<CRFNode, CRFEdge>();
        public INodeLogic<CRFNode, CRFEdge> Logic
        {
            get { return logic; }
        }
    }

    public class CRFEdge : IHas<IEdgeLogic<CRFNode, CRFEdge>>
    {
        public CRFEdge()
        {

        }
        public CRFEdge(CRFNode head, CRFNode foot)
        {
            this.Connect(head, foot);
        }
        public double TempScore()
        {
            return Scores[logic.Head.TempAssign, logic.Foot.TempAssign];
        }
        public double Score(CRFNode node1, int label1, CRFNode node2, int label2)
        {
            if (this.Head().Equals(node1))
            {
                return Scores[label1, label2];
            }
            else
                return Scores[label2, label1];
        }
        public double Score(AgO<int, int> state)
        {
            return Scores[state.Data1, state.Data2];
        }
        public double Score(int state1, int state2)
        {
            return Scores[state1, state2];
        }
        public double[,] Scores { get; set; }

        private EdgeLogic<CRFNode, CRFEdge> logic = new EdgeLogic<CRFNode, CRFEdge>();
        public IEdgeLogic<CRFNode, CRFEdge> Logic
        {
            get { return logic; }
        }
    }

    public static class CRFNodeX
    {

    }
}
