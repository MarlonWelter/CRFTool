﻿using General.General;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace CRFBase
{
    public class CRFInput
    {
        public static CRFGraph ParseFile(string file)
        {

            var graph = new CRFGraph();

            using (var reader = new StreamReader(file))
            {
                if (reader.ReadLine() != "numlabels:")
                    throw new IOException("unbekanntes FileFormat - File sollte mit 'numlabels:' beginnen");

                int numberLabels = int.Parse(reader.ReadLine());
                if (reader.ReadLine() != "nodes:")
                    throw new IOException("unbekanntes FileFormat - File sollte 'nodes:' in Zeile 3 enthalten");

                string line = string.Empty;
                while ((line = reader.ReadLine()) != "edges:")
                {
                    string[] words = Regex.Split(line, "\\s");
                    CRFNode node = new CRFNode();
                    var scores = new List<double>();
                    for (int counter = 1; counter < numberLabels + 1; counter++)
                    {
                        try
                        {
                            scores.Add(double.Parse(words[counter], CultureInfo.InvariantCulture));
                        }
                        catch (FormatException ex)
                        {
                            if (words[counter].Equals("N_INF"))
                                scores.Add(double.NegativeInfinity);
                            else
                                throw new Exception();
                        }
                    }
                    graph.Nodes.Add(node);
                    node.Scores = scores.ToArray();
                    node.Id = words[0];

                }
                while ((line = reader.ReadLine()) != null)
                {
                    string[] words = Regex.Split(line, "\\s");
                    string name = words[0] + "_" + words[1];
                    string check = words[1] + "_" + words[0];

                    //Don't use the double occurence edges
                    if (words[0].CompareTo(words[1]) > 0)
                        continue;

                    var edge = new CRFEdge(graph.Nodes.First((n) => n.Id.Equals(words[0])), graph.Nodes.First((n) => n.Id.Equals(words[1])));

                    graph.Edges.Add(edge);

                    edge.Scores = new double[numberLabels, numberLabels];
                    int word = 2;
                    for (int dounter = 0; dounter < numberLabels; dounter++)
                    {
                        for (int counter = 0; counter < numberLabels; counter++)
                        {
                            edge.Scores[dounter, counter] = (double.Parse(words[word], CultureInfo.InvariantCulture));
                            word++;
                        }
                    }

                }
            }
            return graph;
        }

        public static CRFGraph ParseFileFormatTwo(string file)
        {

            var graph = new CRFGraph();

            using (var reader = new StreamReader(file))
            {

                string line = string.Empty;
                while ((line = reader.ReadLine()) != null)
                {
                    if (line.StartsWith("#"))
                    {
                        continue;
                    }
                    else if (line.StartsWith("NODE"))
                    {
                        string[] words = Regex.Split(line, "\\s").Where(s => !string.IsNullOrWhiteSpace(s)).ToArray();
                        CRFNode node = new CRFNode();
                        var scores = new List<double>();
                        for (int counter = 0; counter < 2; counter++)
                        {
                            try
                            {
                                scores.Add(double.Parse(words[counter + 5], CultureInfo.InvariantCulture));
                            }
                            catch (FormatException ex)
                            {
                                if (words[counter + 5].Equals("N_INF"))
                                    scores.Add(double.NegativeInfinity);
                                else
                                    throw new Exception();
                            }
                        }
                        graph.Nodes.Add(node);
                        node.Scores = scores.ToArray();
                        node.Id = words[1];
                        node.ReferenceLabel = int.Parse(words[7]);

                    }
                    else if (line.StartsWith("NEIGH"))
                    {
                        string[] words = Regex.Split(line, "\\s").Where(s => !string.IsNullOrWhiteSpace(s)).ToArray();

                        var stringNode = words[1].Substring(0, words[1].Length - 1);

                        for (int nb = 2; nb < words.Length; nb++)
                        {
                            //Don't use the double occurence edges
                            if (stringNode.CompareTo(words[nb]) > 0)
                                continue;

                            var edge = new CRFEdge(graph.Nodes.First((n) => n.Id.Equals(stringNode)), graph.Nodes.First((n) => n.Id.Equals(words[nb])));

                            graph.Edges.Add(edge);
                        }
                    }

                }
            }
            return graph;
        }

        //Davids files
        public static CRFGraph ParseFileFormatThree(string file)
        {

            var graph = new CRFGraph();

            var edgeMode = false;
            int CountAdd = 0;

            using (var reader = new StreamReader(file))
            {

                string line = string.Empty;
                while ((line = reader.ReadLine()) != null)
                {
                    if (line.Equals("NODES"))
                    {
                        reader.ReadLine();
                        edgeMode = false;

                    }
                    else if (line.Equals("EDGES"))
                    {
                        reader.ReadLine();
                        edgeMode = true;
                    }
                    else if (!edgeMode)
                    {
                        string[] words = Regex.Split(line, ";");
                        CRFNode node = new CRFNode();
                        var scoreI = int.Parse(words[1]);
                        var scoreN = int.Parse(words[2]);
                        var scores = new List<double>();
                        scores.AddRange(scoreN + CountAdd, scoreI + CountAdd);
                        graph.Nodes.Add(node);
                        node.Scores = scores.ToArray();
                        node.Id = words[0];
                        node.ReferenceLabel = (words[3].Equals("N")) ? 0 : 1;
                    }
                    else
                    {
                        string[] words = Regex.Split(line, ";");
                        var headId = words[0];
                        var footId = words[1];
                        var head = graph.Nodes.First(n => n.Id.Equals(headId));
                        var foot = graph.Nodes.First(n => n.Id.Equals(footId));

                        var edge = new CRFEdge(head, foot);
                        graph.Edges.Add(edge);
                    }
                }
            }
            return graph;
        }
    }
}
