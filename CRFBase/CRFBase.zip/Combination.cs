﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using General.BasicOperation;
using General.General;
using System.Collections;

namespace CRFBase
{
    public class Combination : IComparable<Combination>
    {

        public Combination()
        {
        }

        public Combination(Combination parent)
        {
            Assignment = new int[parent.Assignment.Length];
        }
        public int[] Assignment { get; set; }

        public double Score { get; set; }
        public double LastAddedScore { get; set; }
        public string BorderFingerPrint { get; set; }
        public CRFNode LastNodeAdded { get; set; }
        public void AddScore(CRFNode chosenVertex, int state)
        {
            var addedScore = 0.0;

            Assignment[chosenVertex.Ordinate] = state;

            addedScore += chosenVertex.Score(state);
            //Console.WriteLine("Vertex " + chosenVertex.Id + ":  " + chosenVertex.Score(state));
            foreach (var edge in chosenVertex.Edges())
            {
                CRFNode otherVertex = chosenVertex.Neighbour(edge);
                if (!otherVertex.IsChosen)
                    continue;
                if (edge.Head().Equals(chosenVertex))
                    addedScore += edge.Score(new AgO<int, int>(state, Assignment[otherVertex.Ordinate]));
                else
                    addedScore += edge.Score(new AgO<int, int>(state, Assignment[otherVertex.Ordinate]));
            }
            Score += (addedScore);
            LastAddedScore = (addedScore);
            LastNodeAdded = chosenVertex;
            //checkState();
        }

        public override string ToString()
        {
            string name = "";
            foreach (var vertex in Assignment)
            {
                name += "Vertex " + vertex + ": " + Assignment[vertex] + "\n";
            }
            return name;
        }

        public int CompareTo(Combination other)
        {
            if (Score > other.Score)
                return 1;
            else if (Score == other.Score)
                return 0;
            return -1;
        }
    }
}
